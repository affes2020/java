package ecat.DAO;

import static org.junit.Assert.assertEquals;

import java.util.List;

import org.junit.Test;

import ecat.Model.Category;
import ecat.Model.Product;
public class CategoryDAOTest {
	
	
	
	@Test
	 public void testParentCategories(){
		 CategoryDAO catDao = new CategoryDAO();
		 List<Category> parentCategories= catDao.getParentCategories();
		 
		 for (Category cat : parentCategories) {
			 assertEquals(cat.ParentId, 0);

		 }
	   }
	@Test

	 public void testSubCategories(){
		 CategoryDAO catDao = new CategoryDAO();
		 List<Category> parentCategories= catDao.getParentCategories();
		 List<Category> subCategores = catDao.getCategoriesByParentId(parentCategories.get(0).Id);
		 for (Category cat : subCategores) {
			 assertEquals(cat.ParentId, parentCategories.get(0).Id);

		 }
	   }
	@Test
	public void produtsByCategoryId(){
		 ProductDAO prodDao = new ProductDAO();
		 CategoryDAO catDao = new CategoryDAO();
		 List<Category> subsubCategories = catDao.getParentCategories();
		 while(catDao.getCategoriesByParentId(subsubCategories.get(0).Id).size() > 0){
			 subsubCategories = catDao.getCategoriesByParentId(subsubCategories.get(0).Id);
		 }
		 List<Product> products= prodDao.getProductsByCategoryId(subsubCategories.get(0).Id);
		 
		 for (Product prod : products) {
			 assertEquals(prod.CategoryId ,subsubCategories.get(0).Id);
		 }
	   }
	
	@Test
	public void productsByReferece(){
		 ProductDAO prodDao = new ProductDAO();
		 CategoryDAO catDao = new CategoryDAO();
		 List<Category> subsubCategories = catDao.getParentCategories();
		 while(catDao.getCategoriesByParentId(subsubCategories.get(0).Id).size() > 0){
			 subsubCategories = catDao.getCategoriesByParentId(subsubCategories.get(0).Id);
		 }
		 List<Product> products= prodDao.getProductsByCategoryId(subsubCategories.get(0).Id);
		 Product c = prodDao.getProductsByReference(products.get(0).Reference).get(0);
			 assertEquals(c.Reference ,products.get(0).Reference);

	   }
}
