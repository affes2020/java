package ecat.databaseTest;

import static org.junit.Assert.assertEquals;

import org.junit.Test;

import ecat.database.Database;


public class DatabaseTest 
    
{
 
	@Test
	 public void testDatabase(){
	     Database db = new Database();
	     
	     assertEquals(db.getConn(),Database.conn);
	   }

   
}
