package ecat.database;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

/*
 * Database singleton class
 */
public class Database {
	
	private static Database DatabaseIntance = null;
    public static Connection  conn;
    //Constructor
    public Database() {
    	Connector();
    }
    // get database checks for existing instance and returns it if it exists, otherwise it creates a new one
	public static Database getDatabase() {
		 if (DatabaseIntance == null)
			 DatabaseIntance = new Database();
	  
	        return DatabaseIntance;
	}
	//setter for connection property
	public static void setConn(Connection conn) {
		Database.conn = conn;
	}
	
	public static Connection getConn() {
		return Database.conn ;
	}
	// connector method used to establish connection with sqlite database
	public  static  void Connector()
	{
		try {
			Class.forName("org.sqlite.JDBC");
			conn = DriverManager.getConnection("jdbc:sqlite:DB/ecat.db");
		}catch(Exception e) {
			
			e.printStackTrace();
			}
	}
	
	    public void close() {
	        try {
	            conn.close();
	        } catch (SQLException e) {
	            e.printStackTrace();
	        }
	    }
	  
	    }


	


