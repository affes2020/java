package ecat;

import java.util.List;
import java.util.Scanner;

import ecat.DAO.CategoryDAO;
import ecat.DAO.ProductDAO;
import ecat.Model.Category;
import ecat.Model.Product;

/*
 * Main class app
 * Starting point the program
 * 
 * 
 */
public class App 
{
	// scanner used to read user input
	public static    Scanner userInput;
	// CategoryData data access class used to access the data about categories in the database
	public static	CategoryDAO categoryData;
	// Product data access class used to access the data about products in the database

	public static	ProductDAO productData;
	
	
	/*
	 * 
	 * main method
	 * Instanciate variable used in the program and calls method to process user requests
	 */

    public static void main( String[] args )
    {
    	userInput=new Scanner(System.in);  
    	categoryData = new CategoryDAO();
    	productData = new ProductDAO();
    	
    	System.out.println("Welcome to the e-catalogue");
    	int k = 0;
    	while (k >2 || k <= 0) {
    	System.out.println("Please Choose one option : ");
    	System.out.println("1 - Browse catalogue ");
    	System.out.println("2 - Search for product ");
		k= userInput.nextInt();  
    	}
    	if(k == 1) {
    		// call browseCatalogue if user chooses option 1
    		browseCatalogue();
    	}
    	else {
    		// call searchForProduct if user chooses option 2

    		searchForProduct();
    	}

    		    	
    }

    /*
     * Method browse Catalogue
     * Used to display the main categories which don't have a parent category 
     * and the calls getSubCategories to display the subcategories  
     */
	public static void browseCatalogue() {
		
    	System.out.println("Main catagories : ");
    	System.out.println("#############################################");
		List<Category> categories = categoryData.getParentCategories();
    	int i = 1;
    	for(Category c : categories) {
    		System.out.println( i++ +"- " +c.toString());
    	}
    	System.out.println("############################################# \n \n");

      		
    		getSubCategories(categories);
      
    	}
	/*
     * Method getSubCategories
     * Used to interact with the user according the his choice in categories
     * Display subcategories until there's no subcategory and calls methos to display products
     */
	public static void getSubCategories(List<Category> categories) {
		  System.out.print("Please select Category number to display sub-categories - : ");  
			int k= userInput.nextInt(); 
		  while(k <= 0 || k > categories.size() ) {
			  System.out.print("wrong number ,Please select Category number to display sub-categories - : ");  
				k= userInput.nextInt(); 
		  }
		  // in case selected category contains subcategories
	    	if(categoryData.getCategoriesByParentId(categories.get(k-1).getId()).size() > 0) {
	    		categories  = categoryData.getCategoriesByParentId(categories.get(k-1).getId());
	    	int i = 1;
	    	System.out.println("#############################################");
	    	for(Category c : categories) {
	    		System.out.println( i++ +"- " +c.toString());

	    	}
	    	System.out.println("############################################# \n \n");
	    	getSubCategories(categories);
	    	}
	    	// in case selected category doesn't contain any subcategory
	    	else {
		    	System.out.println("No subcategory found");
		    	System.out.println("List of products in category : ");
	    		getProductsOfCategory(categories.get(k-1).getId());
	    	}
	}
	
	/*
	 * Method getProductsOfCategory takes CategoryId as an input and displays all product of that category to the user
	 */
	public static void getProductsOfCategory(int  Id) {
		int i = 1;
		List<Product> productList = productData.getProductsByCategoryId(Id);
    	System.out.println("#############################################");
    	for(Product c : productList) {
    		System.out.println( i++ +"- " +c.Reference);
    	}
    	System.out.println("############################################# \n \n");
    	// call selectProductForDetails to make the user select the product for which he wants to see details
    	selectProductForDetails(productList);
	}
	
	
	/*
	 * method selectProductForDetails used to display details of product selected by user
	 */
	public static void selectProductForDetails(List<Product> productList) {
		  System.out.print("Please select product number for details - : ");  
			int k= userInput.nextInt(); 
		  while(k <= 0 || k > productList.size() ) {
			  System.out.print("wrong number ,Please select product number for details  - : ");  
				k= userInput.nextInt(); 
		  }
	    System.out.println("#############################################");
	    System.out.println("Product description");

  		System.out.println(productList.get(k-1).toString());
    	System.out.println("#############################################");
		System.out.println("----------------------------------------------------------");
		// when method is finish call main method to restart the program
		main(null);
	    		
	}
	
	/*
	 * searchForProduct used to search for products by reference or description
	 * 
	 */
	 private static void searchForProduct() {
		  int i = 1 ;
		  System.out.println("Please type reference - : ");  
		    Scanner myObj = new Scanner(System.in);

			String Ref= myObj.nextLine();
			
			System.out.println("Ref " + Ref);
			
			List<Product> productList = productData.getProductsByReference(Ref);
			productList.addAll(productData.getProductsByDescription(Ref));
			for(Product c : productList) {
	    		System.out.println( i++ +"- " +c.Reference);
	    	}
			System.out.println("----------------------------------------------------------");
			// when method is finish call main method to restart the program
			main(null);
		}
	


}
