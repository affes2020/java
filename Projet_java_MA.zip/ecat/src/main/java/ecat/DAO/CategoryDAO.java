package ecat.DAO;

import ecat.Model.Category;
import ecat.database.Database;

import java.sql.*;
import java.util.*;

public class CategoryDAO {

	
    /*
     * getParentCategories
     * Method takes no parameters.
     * used to get categories which parentId is empty
     */
    public List<Category> getParentCategories() {
        try {
        	Database.getDatabase();
        	// get connection
            Connection con = Database.getConn();
            // prepare query
            PreparedStatement statement = con.prepareStatement
                    ("select * from Categories where ParentId IS NULL"
                    );
            ResultSet resultSet = statement.executeQuery();
            List<Category> categories = new ArrayList<Category>();
            Category category ;
            // loop through result set of categories
            while (resultSet.next()){
            	// fill category info
                category = new Category();
            	category.setId(resultSet.getInt("Id"));
            	category.setParentId(resultSet.getInt("ParentId"));
            	category.setLevel(resultSet.getInt("Level"));
            	category.setImage(resultSet.getString("Image"));
            	// prepare second query to get the category names
            	PreparedStatement statement1 = con.prepareStatement
                        ("select * from CategoryNames where CategoryId ='"+category.getId()+"'"
                        );
                ResultSet resultSet1 = statement1.executeQuery();
                while (resultSet1.next()){
                	category.categoryName.Value = resultSet1.getString("Value");
                }
                
                categories.add(category);
            }
            // return categories
            return categories;
        } catch (SQLException /*| ParseException*/ e) {
            e.printStackTrace();
            return null;
        }

    }
    /*
     * getCategoriesByParentId
     * Method takes as parameter the parentId and return all categories that have that parentId
     */
    public List<Category> getCategoriesByParentId(int Id) {
        try {
        	Database.getDatabase();
        	// get connection
            Connection con = Database.getConn();
            // prepare query to get categories based on parentId
            PreparedStatement statement = con.prepareStatement
                    ("select * from Categories where ParentId ='"+Id+"'"
                    );
            ResultSet resultSet = statement.executeQuery();
            List<Category> categories = new ArrayList<Category>();
            Category category;
            // loop through result set to get categories
            while (resultSet.next()){
            	category = new Category();
            	category.setId(resultSet.getInt("Id"));
            	category.setParentId(resultSet.getInt("ParentId"));
            	category.setLevel(resultSet.getInt("Level"));
            	category.setImage(resultSet.getString("Image"));
            	PreparedStatement statement1 = con.prepareStatement
                        ("select * from CategoryNames where CategoryId ='"+category.getId()+"'"
                        );
                ResultSet resultSet1 = statement1.executeQuery();
                while (resultSet1.next()){
                	category.categoryName.Value = resultSet1.getString("Value");
                }
                
                categories.add(category);
            }
            // return categories
            return categories;
        } catch (SQLException /*| ParseException*/ e) {
            e.printStackTrace();
            return null;
        }

    }
  
}
