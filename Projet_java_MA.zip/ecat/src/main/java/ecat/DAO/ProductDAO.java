package ecat.DAO;

import ecat.Model.Category;
import ecat.Model.PFeature;
import ecat.Model.PFeatureValue;
import ecat.Model.Product;
import ecat.Model.ProductDescription;
import ecat.database.Database;

import java.sql.*;
import java.util.*;
public class ProductDAO {

	/*
	 *  Method getProductsByCategoryId
	 *  Takes as input the category id
	 *  return list of products in the category
	 */
	public List<Product> getProductsByCategoryId(int categoryId) {
        try {
        	Database.getDatabase();
        	// get connection from singleton class
            Connection con = Database.getConn();
            // prepare the query to get the products from the database
            PreparedStatement statement = con.prepareStatement
                    ("select * from Products  where CategoryId ='"+categoryId+"'"
                    );
            ResultSet resultSet = statement.executeQuery();
            List<Product> products = new ArrayList<Product>();

            Product product ;
            // loop over the resultSet and fill the list with products
            while (resultSet.next()){
            	product = new Product();
            	product.setId(resultSet.getInt("Id"));
            	product.setEAN(resultSet.getString("EAN"));
            	product.setCategoryId(resultSet.getInt("CategoryId"));
            	product.setReference(resultSet.getString("Reference"));
            	product.setPrice(resultSet.getFloat("Price"));
            	product.setPackQuantity(resultSet.getInt("PackQuantity"));
            	// prepare query to get productDescriptions data about the product
            	statement = con.prepareStatement
                        ("select * from ProductDescriptions where productId ='"+product.getId()+"'"
                        );
                ResultSet resultSet1 = statement.executeQuery();
                while (resultSet1.next()){
                	// set the productdescription value on the product
                	product.productDescription.Value = resultSet1.getString("Value");
                }
                // prepare the query to get data about product features
                statement = con.prepareStatement
                        ("select * from PFeatures where productId ='"+product.getId()+"'"
                        );
                ResultSet resultSet2 = statement.executeQuery();
                while (resultSet2.next()){
                	PFeature feature = new PFeature();
                	feature.Id=resultSet2.getInt("Id");
                	// prepare query to get product features values to complete the informations of 
                	// the product that'll be printed to the used in the console
                	 statement = con.prepareStatement
                             ("select * from PFeatureValues where PFeatureId ='"+feature.Id+"'"
                             );
                     ResultSet resultSet3 = statement.executeQuery();
                     while (resultSet3.next()){
                     	PFeatureValue featureValue = new PFeatureValue();
                     	featureValue.Value = resultSet3.getString("Value");
                     	feature.PFeatureValue=featureValue;
                     }
                     product.PFeatures.add(feature);
                }
                // add product to list
                products.add(product);

             
            }
            // return products
            return products;
        } catch (SQLException /*| ParseException*/ e) {
            e.printStackTrace();
            return null;
        }

    }
	
	/*
	 * getProductsByReference
	 * used to get products based on the reference value
	 * take as input the a String parameter and searches the database for product which reference contains the ref passed in parameter
	 */
	public List<Product> getProductsByReference(String Ref) {
        try {
        	Database.getDatabase();
            Connection con = Database.getConn();
            // prepare query
            PreparedStatement statement = con.prepareStatement
                    ("select * from Products  where Reference LIKE '%"+Ref+"%'"
                    );
            ResultSet resultSet = statement.executeQuery();
            List<Product> products = new ArrayList<Product>();

            Product product ;

            // loop through resultset and fill product list
            while (resultSet.next()){
            	product = new Product();
            	product.setId(resultSet.getInt("Id"));
            	product.setEAN(resultSet.getString("EAN"));
            	product.setReference(resultSet.getString("Reference"));
            	product.setPrice(resultSet.getFloat("Price"));
            	product.setPackQuantity(resultSet.getInt("PackQuantity"));
            	statement = con.prepareStatement
                        ("select * from ProductDescriptions where productId ='"+product.getId()+"'"
                        );
                ResultSet resultSet1 = statement.executeQuery();
                while (resultSet1.next()){
                	product.productDescription.Value = resultSet1.getString("Value");
                }
                products.add(product);

             
            }
            // return product list
            return products;
        } catch (SQLException /*| ParseException*/ e) {
            e.printStackTrace();
            return null;
        }

    }
	/*
	 * getProductsByDescription
	 * take as parameter a String parameter called Ref
	 * uses this parameter to search in the databaase for product which description contains that ref
	 */
	public List<Product> getProductsByDescription(String Ref) {
        try {
        	Database.getDatabase();
            Connection con = Database.getConn();
            // preapre query
            PreparedStatement statement = con.prepareStatement
                    ("SELECT * from ProductDescriptions,Products where ProductDescriptions.Value like '%"+
            Ref+"%' and ProductDescriptions.ProductId = Products.Id"
                    );
            ResultSet resultSet = statement.executeQuery();
            List<Product> products = new ArrayList<Product>();

            Product product ;
            // loop through result set of product
            while (resultSet.next()){
            	product = new Product();
            	product.setId(resultSet.getInt("Id"));
            	product.setEAN(resultSet.getString("EAN"));
            	product.setReference(resultSet.getString("Reference"));
            	product.setPrice(resultSet.getFloat("Price"));
            	product.setPackQuantity(resultSet.getInt("PackQuantity"));
            	statement = con.prepareStatement
                        ("select * from ProductDescriptions where productId ='"+product.getId()+"'"
                        );
                ResultSet resultSet1 = statement.executeQuery();
                while (resultSet1.next()){
                	product.productDescription.Value = resultSet1.getString("Value");
                }
                products.add(product);

             
            }
            // return list of products
            return products;
        } catch (SQLException /*| ParseException*/ e) {
            e.printStackTrace();
            return null;
        }

    }
}
