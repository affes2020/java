package ecat.Model;

/*
 * Category name class
 * 
 */
public class CategoryName {
    public int Id;
    public int CategoryId;
    public String Value;
    public int Language;

    public int getId() {
        return Id;
    }

    public void setId(int id) {
        Id = id;
    }

    public int getCategoryId() {
        return CategoryId;
    }

    public void setCategoryId(int categoryId) {
        CategoryId = categoryId;
    }

    public String getValue() {
        return Value;
    }
    public void setValue(String Value){
        this.Value = Value;
    }

    public int getLanguage() {
        return Language;
    }

    public void setLanguage(int Language){
        this.Language = Language;
    }
}
